// path/to/your/predicciones.js
const ARIMA = require('arima');
const regression = require('regression');
const Venta = require('../models/Venta');
const Almacen = require('../models/Almacen');

// Obtener ventas diarias
async function obtenerVentasDiarias() {
  const fechaLimite = new Date();
  fechaLimite.setMonth(fechaLimite.getMonth() - 6);

  try {
    const ventas = await Venta.aggregate([
      {
        $match: {
          fecha_registro: { $gte: fechaLimite }
        }
      },
      { $unwind: '$productos' },
      {
        $group: {
          _id: {
            producto: '$productos.producto',
            fecha: { $dateToString: { format: '%Y-%m-%d', date: '$fecha_registro' } }
          },
          totalVentas: { $sum: '$productos.cantidad_producto' }
        }
      },
      { $sort: { '_id.producto': 1, '_id.fecha': 1 } }
    ]);

    const ventasPorProducto = {};
    ventas.forEach(venta => {
      const productoId = venta._id.producto;
      const fechaVenta = venta._id.fecha;

      if (!ventasPorProducto[productoId]) {
        ventasPorProducto[productoId] = [];
      }

      ventasPorProducto[productoId].push({ fecha: fechaVenta, totalVentas: venta.totalVentas });
    });

    return ventasPorProducto;
  } catch (error) {
    console.error('Error al obtener las ventas diarias:', error);
    throw error;
  }
}

// Predicción usando Promedio Móvil
function predecirPromedioMovil(datosHistoricos, diasAPredecir) {
  const windowSize = 7;
  const predicciones = [];

  for (let i = 0; i < diasAPredecir; i++) {
    const start = Math.max(0, datosHistoricos.length - windowSize);
    const window = datosHistoricos.slice(start);
    const average = window.reduce((sum, value) => sum + value.totalVentas, 0) / window.length;
    predicciones.push(average);
  }

  return predicciones;
}

// Predicción usando Regresión Lineal
function predecirRegresionLineal(datosHistoricos, diasAPredecir) {
  const datos = datosHistoricos.map((dato, index) => [index, dato.totalVentas]);
  const result = regression.linear(datos);

  const predicciones = [];
  const lastIndex = datosHistoricos.length - 1;

  for (let i = 1; i <= diasAPredecir; i++) {
    const prediccion = result.predict(lastIndex + i)[1];
    predicciones.push(prediccion);
  }

  return predicciones;
}

// Predicción usando ARIMA
const ArimaModel = require('../models/arimaModel'); // Ajusta la ruta según tu estructura de proyecto
// Predicción usando ARIMA
async function predecirVentas(ventasPorProducto, productoId, diasAPredecir) {
  const datosHistoricos = ventasPorProducto[productoId] || [];
  if (datosHistoricos.length === 0) {
    throw new Error(`No hay datos históricos para el producto con ID ${productoId}`);
  }

  const y = datosHistoricos.map(venta => venta.totalVentas);
  const arima = new ARIMA({ p: 1, d: 2, q: 1, verbose: false });
  arima.train(y);
  const prediccionesARIMA = arima.predict(diasAPredecir);

  const prediccionesPromedioMovil = predecirPromedioMovil(datosHistoricos, diasAPredecir);
  const prediccionesRegresionLineal = predecirRegresionLineal(datosHistoricos, diasAPredecir);

  const producto = await Almacen.findById(productoId).populate('producto', 'nombre').populate('categoria', 'nombre');
  const capacidadTotalInicial = calcularCapacidadTotalInicial(producto);

  const primeraPrediccionARIMA = prediccionesARIMA[0].map(valor => Math.ceil(valor));
  const primeraPrediccionPromedioMovil = prediccionesPromedioMovil.map(valor => Math.ceil(valor));
  const primeraPrediccionRegresionLineal = prediccionesRegresionLineal.map(valor => Math.ceil(valor));

  let capacidadTotal = capacidadTotalInicial;
  let agotado = false;
  let diaAgotamiento;

  const erroresAbsolutosMediosARIMA = calcularErrorAbsolutoMedio(primeraPrediccionARIMA, datosHistoricos);
  const erroresAbsolutosMediosPromedioMovil = calcularErrorAbsolutoMedio(primeraPrediccionPromedioMovil, datosHistoricos);
  const erroresAbsolutosMediosRegresionLineal = calcularErrorAbsolutoMedio(primeraPrediccionRegresionLineal, datosHistoricos);

  for (let i = 0; i < primeraPrediccionARIMA.length; i++) {
    const ventaDiaActual = primeraPrediccionARIMA[i];
    capacidadTotal -= ventaDiaActual;
    if (!agotado && capacidadTotal <= 0) {
      diaAgotamiento = i + 1;
      agotado = true;
      break;
    }
  }

  return {
    producto: producto._id,
    nombreCategoria: producto.categoria.nombre, 
    nombreProducto: producto.producto.nombre, 
    prediccion: {
      arima: { ventas: primeraPrediccionARIMA, stockRestante: Math.max(capacidadTotal, 0) },
      promedioMovil: primeraPrediccionPromedioMovil,
      regresionLineal: primeraPrediccionRegresionLineal
    }, 
    diaAgotamiento,
    datosHistoricos: datosHistoricos.length,
    porcentajeErrorARIMA: parseFloat(erroresAbsolutosMediosARIMA),
    porcentajeErrorPromedioMovil: parseFloat(erroresAbsolutosMediosPromedioMovil),
    porcentajeErrorRegresionLineal: parseFloat(erroresAbsolutosMediosRegresionLineal),
  };
}

// Calcular el error absoluto medio
function calcularErrorAbsolutoMedio(predicciones, datosHistoricos) {
  let sumaErrores = 0;
  let count = Math.min(predicciones.length, datosHistoricos.length);

  for (let i = 0; i < count; i++) {
    const error = Math.abs(predicciones[i] - datosHistoricos[i].totalVentas);
    sumaErrores += error;
  }

  return (sumaErrores / count).toFixed(2);
}

// Calcular capacidad total inicial
function calcularCapacidadTotalInicial(producto) {
  if (!producto) {
    throw new Error(`Producto no definido`);
  }
  let capacidadTotal = 0;
  if (producto.cantidad_stock <= 0) {
    capacidadTotal = producto.cantidad_stock - producto.cantidad_producto;
  } else {
    capacidadTotal = producto.cantidad_stock;
  }

  return capacidadTotal;
}

// Predicción para todos los productos
async function predecirVentasParaTodosLosProductos(diasAPredecir) {
  try {
    const ventasPorProducto = await obtenerVentasDiarias();
    const productos = await Almacen.find({});
    const predicciones = await Promise.all(
      productos.map(producto => predecirVentas(ventasPorProducto, producto._id, diasAPredecir))
    );

    const productosConDiaAgotamiento = predicciones.map(prediccion => ({
      ...prediccion,
      diaAgotamiento: prediccion.diaAgotamiento,
    }));

    return productosConDiaAgotamiento;
  } catch (error) {
    console.error('Error al predecir ventas para todos los productos:', error);
    throw error;
  }
}

module.exports = { predecirVentasParaTodosLosProductos };