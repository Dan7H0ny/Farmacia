const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const prediccionesSchema = new Schema({
  producto: { type: Schema.Types.ObjectId, ref: 'Almacen', required: true },
  nombreCategoria: { type: String, required: true },
  nombreProducto: { type: String, required: true },
  prediccion: {
    ventas: [Number],
    stockRestante: Number
  },
  diaAgotamiento: Number,
  datosHistoricos: Number,
  porcentajeError: Number,
  fechaCreacion: { type: Date, default: Date.now }
});

const Predicciones = mongoose.model('Predicciones', prediccionesSchema);
module.exports = Predicciones;
